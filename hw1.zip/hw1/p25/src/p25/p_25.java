package p25;

public class p_25 {

	public static void main(String[] args)
	{
		int num;
		
		num=3;
		
		System.out.print("�ܼ�num���ȬO"+num);
	}
}
