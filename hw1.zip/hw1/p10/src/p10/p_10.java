/**
 * 
 */
package p10;

/**
 * @author user
 *
 */
public class p_10 {

	public static void main(String[] args)
	{
		System.out.println("�w��ϥ�java");
		System.out.println("�}�l�ϥ�java�a");

	}
}
